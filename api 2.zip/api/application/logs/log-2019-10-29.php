<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-29 09:38:29 --> 404 Page Not Found: Auth/update_password
ERROR - 2019-10-29 09:38:38 --> 404 Page Not Found: Employee/update_password
ERROR - 2019-10-29 09:40:20 --> Severity: error --> Exception: Call to undefined method Employee_model::update() /var/www/html/aset/api/application/controllers/Employee.php 237
ERROR - 2019-10-29 09:41:47 --> Severity: Notice --> Undefined variable: employee_id /var/www/html/aset/api/application/controllers/Employee.php 237
