<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-29 12:50:57 --> Severity: Notice --> Array to string conversion /var/www/html/aset/api/system/database/DB_query_builder.php 837
ERROR - 2019-09-29 12:50:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `access_control_list`
WHERE `role` IN('EMPLOYEE', Array)
