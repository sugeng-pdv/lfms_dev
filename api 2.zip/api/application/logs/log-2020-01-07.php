<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-07 03:19:55 --> Query error: Column 'total_surface_area' cannot be null - Invalid query: INSERT INTO `land` (`asset_id`, `certificate_number`, `type_of_land_right`, `total_surface_area`, `certificate_expiration_date`, `rights_holder`) VALUES ('182', 'SHGB 1000/Bintara Jaya', 'Hak Guna Bangunan', NULL, NULL, NULL)
