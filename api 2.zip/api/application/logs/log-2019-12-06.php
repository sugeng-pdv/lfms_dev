<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-06 09:10:06 --> 404 Page Not Found: Public/asset
