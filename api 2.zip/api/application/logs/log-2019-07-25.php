<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-25 13:45:46 --> Severity: error --> Exception: Call to undefined function mysqli_init() /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2019-07-25 13:46:02 --> Severity: error --> Exception: Call to undefined function mysqli_init() /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2019-07-25 13:48:12 --> 404 Page Not Found: Asset/get_assets
ERROR - 2019-07-25 13:48:29 --> 404 Page Not Found: Assets/get_assets
ERROR - 2019-07-25 13:49:22 --> Severity: error --> Exception: Call to undefined function mysqli_init() /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 135
