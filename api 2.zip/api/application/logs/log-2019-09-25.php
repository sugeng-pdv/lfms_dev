<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-25 04:25:51 --> Severity: Notice --> Undefined index: contract/update_tenant /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-25 04:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-25 04:25:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
