<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-18 04:29:52 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
ERROR - 2019-08-18 04:32:11 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
ERROR - 2019-08-18 04:32:32 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
ERROR - 2019-08-18 04:34:02 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
ERROR - 2019-08-18 06:13:34 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
ERROR - 2019-08-18 07:01:05 --> Severity: Notice --> Undefined variable: id /var/www/html/aset/api/application/models/Employee_model.php 28
ERROR - 2019-08-18 07:01:52 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/aset/api/system/database/DB_query_builder.php 2442
ERROR - 2019-08-18 07:01:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 4 - Invalid query: SELECT *
FROM `employee`
WHERE `id` = 
 LIMIT 1
ERROR - 2019-08-18 08:58:21 --> Severity: Warning --> Constants may only evaluate to scalar values or arrays /var/www/html/aset/api/application/libraries/Access_control.php 45
ERROR - 2019-08-18 08:58:21 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Auth.php 36
ERROR - 2019-08-18 08:59:18 --> Severity: Warning --> Constants may only evaluate to scalar values or arrays /var/www/html/aset/api/application/libraries/Access_control.php 45
ERROR - 2019-08-18 08:59:18 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Auth.php 36
ERROR - 2019-08-18 08:59:33 --> Severity: Warning --> Constants may only evaluate to scalar values or arrays /var/www/html/aset/api/application/libraries/Access_control.php 45
ERROR - 2019-08-18 08:59:33 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Auth.php 36
ERROR - 2019-08-18 08:59:41 --> Severity: Warning --> Constants may only evaluate to scalar values or arrays /var/www/html/aset/api/application/libraries/Access_control.php 45
ERROR - 2019-08-18 08:59:41 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Auth.php 36
ERROR - 2019-08-18 09:00:45 --> Severity: Warning --> Constants may only evaluate to scalar values or arrays /var/www/html/aset/api/application/libraries/Access_control.php 45
ERROR - 2019-08-18 09:00:45 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Auth.php 36
ERROR - 2019-08-18 12:21:59 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Asset.php 250
ERROR - 2019-08-18 12:26:34 --> Query error: Table 'lman_asset_service.assets_video' doesn't exist - Invalid query: SELECT *
FROM `assets_video`
WHERE `asset_id` = '13'
