<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 06:26:51 --> Query error: Column 'parent' cannot be null - Invalid query: INSERT INTO `acl_menu` (`parent`, `name`, `link`) VALUES (NULL, 'Privileges Management', 'privileges-management')
ERROR - 2020-09-10 06:27:43 --> Query error: Column 'parent' cannot be null - Invalid query: INSERT INTO `acl_menu` (`parent`, `name`, `link`) VALUES (NULL, 'Privileges Management', 'privileges-management')
ERROR - 2020-09-10 06:28:14 --> Query error: Column 'parent' cannot be null - Invalid query: INSERT INTO `acl_menu` (`parent`, `name`, `link`) VALUES (NULL, 'Privileges Management', 'privileges-management')
ERROR - 2020-09-10 06:28:56 --> Query error: Column 'parent' cannot be null - Invalid query: INSERT INTO `acl_menu` (`parent`, `name`, `link`) VALUES (NULL, 'Privileges Management', 'privileges-management')
