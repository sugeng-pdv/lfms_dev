<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-24 04:30:58 --> Severity: Notice --> Undefined property: Asset::$Category_model /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:30:58 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:31:10 --> Severity: Notice --> Undefined property: Asset::$Asset_category_model /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:31:10 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:31:48 --> Severity: Notice --> Undefined property: Asset::$Asset_category_model /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:31:48 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:33:16 --> Severity: Notice --> Undefined property: Asset::$Asset_category_model /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:33:16 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Asset.php 698
ERROR - 2019-07-24 04:34:14 --> Severity: Notice --> Undefined property: Asset::$Asset_origin_model /var/www/html/aset/api/application/controllers/Asset.php 700
ERROR - 2019-07-24 04:34:14 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Asset.php 700
