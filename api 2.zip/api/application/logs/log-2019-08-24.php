<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-24 02:27:39 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 02:27:39 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 02:59:56 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 02:59:56 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 02:59:57 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 03:00:03 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
ERROR - 2019-08-24 03:00:15 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
