<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-05 00:31:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:31:21 --> Unable to connect to the database
ERROR - 2020-07-05 00:31:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:31:23 --> Unable to connect to the database
ERROR - 2020-07-05 00:31:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:31:28 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:41 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:42 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:50 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:50 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:52 --> Unable to connect to the database
ERROR - 2020-07-05 00:32:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:32:54 --> Unable to connect to the database
ERROR - 2020-07-05 00:44:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:44:04 --> Unable to connect to the database
ERROR - 2020-07-05 00:44:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:44:04 --> Unable to connect to the database
ERROR - 2020-07-05 00:44:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:44:06 --> Unable to connect to the database
ERROR - 2020-07-05 00:44:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:44:53 --> Unable to connect to the database
ERROR - 2020-07-05 00:44:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 00:44:53 --> Unable to connect to the database
ERROR - 2020-07-05 01:05:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 01:05:50 --> Unable to connect to the database
ERROR - 2020-07-05 01:42:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 01:42:12 --> Unable to connect to the database
ERROR - 2020-07-05 03:06:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 03:06:17 --> Unable to connect to the database
ERROR - 2020-07-05 04:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:22:13 --> Unable to connect to the database
ERROR - 2020-07-05 04:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:22:13 --> Unable to connect to the database
ERROR - 2020-07-05 04:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:22:13 --> Unable to connect to the database
ERROR - 2020-07-05 04:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:22:13 --> Unable to connect to the database
ERROR - 2020-07-05 04:22:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:22:41 --> Unable to connect to the database
ERROR - 2020-07-05 04:36:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 04:36:50 --> Unable to connect to the database
ERROR - 2020-07-05 05:18:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 05:18:21 --> Unable to connect to the database
ERROR - 2020-07-05 05:18:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 05:18:21 --> Unable to connect to the database
ERROR - 2020-07-05 05:19:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 05:19:16 --> Unable to connect to the database
ERROR - 2020-07-05 05:19:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 05:19:16 --> Unable to connect to the database
ERROR - 2020-07-05 07:00:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 07:00:24 --> Unable to connect to the database
ERROR - 2020-07-05 07:17:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 07:17:56 --> Unable to connect to the database
ERROR - 2020-07-05 11:26:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 11:26:06 --> Unable to connect to the database
ERROR - 2020-07-05 11:26:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 11:26:15 --> Unable to connect to the database
ERROR - 2020-07-05 11:26:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 11:26:51 --> Unable to connect to the database
ERROR - 2020-07-05 13:58:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:58:28 --> Unable to connect to the database
ERROR - 2020-07-05 13:58:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:58:29 --> Unable to connect to the database
ERROR - 2020-07-05 13:59:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:59:03 --> Unable to connect to the database
ERROR - 2020-07-05 13:59:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:59:04 --> Unable to connect to the database
ERROR - 2020-07-05 13:59:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:59:10 --> Unable to connect to the database
ERROR - 2020-07-05 13:59:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 13:59:34 --> Unable to connect to the database
ERROR - 2020-07-05 15:50:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 15:50:23 --> Unable to connect to the database
ERROR - 2020-07-05 16:10:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-05 16:10:23 --> Unable to connect to the database
