<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-04 07:06:56 --> Severity: Notice --> Undefined index: duty/add_document /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-04 07:06:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-04 07:06:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-04 07:07:39 --> Severity: Notice --> Undefined index: duty/add_document /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-04 07:07:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-04 07:07:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-04 07:12:32 --> Severity: Notice --> Undefined property: Duty::$Asset_value_model /var/www/html/aset/api/application/controllers/Duty.php 31
ERROR - 2019-10-04 07:12:32 --> Severity: error --> Exception: Call to a member function get_document() on null /var/www/html/aset/api/application/controllers/Duty.php 31
