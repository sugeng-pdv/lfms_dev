<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-26 02:54:55 --> Severity: Notice --> Undefined index: contract/contract_detail /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-26 02:54:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-26 02:54:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-26 02:55:34 --> Severity: Notice --> Undefined variable: asset_detail /var/www/html/aset/api/application/controllers/Contract.php 124
ERROR - 2019-09-26 02:55:34 --> Severity: Notice --> Trying to get property 'id' of non-object /var/www/html/aset/api/application/controllers/Contract.php 124
