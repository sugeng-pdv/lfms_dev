<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-12 16:29:40 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-08-12 16:29:40 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
ERROR - 2020-08-12 16:30:08 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-08-12 16:30:08 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
ERROR - 2020-08-12 16:30:58 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-08-12 16:30:58 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
ERROR - 2020-08-12 16:31:06 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-08-12 16:31:06 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
