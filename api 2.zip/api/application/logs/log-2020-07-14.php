<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 13:23:33 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-07-14 13:23:33 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
ERROR - 2020-07-14 13:23:39 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-07-14 13:23:39 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
ERROR - 2020-07-14 13:23:51 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 343
ERROR - 2020-07-14 13:23:51 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Asset.php 344
