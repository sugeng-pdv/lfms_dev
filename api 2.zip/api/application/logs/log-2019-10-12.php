<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-12 10:32:37 --> 404 Page Not Found: Dashboard/revenue_of_year
ERROR - 2019-10-12 10:34:11 --> 404 Page Not Found: Dashboard/revenue_byyear
ERROR - 2019-10-12 10:34:19 --> 404 Page Not Found: Dashboard/revenue_byyear
ERROR - 2019-10-12 10:34:37 --> Severity: Notice --> Undefined variable: payment /var/www/html/aset/api/application/controllers/Dashboard.php 134
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
ERROR - 2019-10-12 11:00:01 --> Severity: Notice --> A non well formed numeric value encountered /var/www/html/aset/api/application/controllers/Dashboard.php 123
