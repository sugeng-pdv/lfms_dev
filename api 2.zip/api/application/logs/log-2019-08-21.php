<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-21 01:49:03 --> Severity: error --> Exception: Call to undefined method Auth::load() /var/www/html/aset/api/application/controllers/Auth.php 80
ERROR - 2019-08-21 01:49:46 --> Query error: Table 'lman_asset_service.employee_token' doesn't exist - Invalid query: INSERT INTO `employee_token` (`jwt_uid`, `employee_id`, `issued`) VALUES ('5d5ca33a87e4b', '1', 1566352186)
ERROR - 2019-08-21 03:12:59 --> 404 Page Not Found: Asset/detail
ERROR - 2019-08-21 03:52:19 --> Severity: Notice --> Undefined property: stdClass::$jwtuid /var/www/html/aset/api/application/libraries/Access_control.php 39
