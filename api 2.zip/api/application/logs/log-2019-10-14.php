<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-14 02:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 185
ERROR - 2019-10-14 02:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 186
