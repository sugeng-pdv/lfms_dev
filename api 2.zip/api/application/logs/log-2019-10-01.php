<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-01 04:08:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-10-01 04:08:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-10-01 04:08:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-10-01 04:08:24 --> Unable to connect to the database
ERROR - 2019-10-01 04:08:24 --> Unable to connect to the database
ERROR - 2019-10-01 04:08:24 --> Unable to connect to the database
ERROR - 2019-10-01 07:30:32 --> Severity: Notice --> Undefined index: asset_value/get_asset_value /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 07:30:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:30:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:32:55 --> Severity: Notice --> Undefined index: asset_value/add_asset_value /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 07:32:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:32:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:36:52 --> Severity: Notice --> Undefined index: asset_value/add_asset_value /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 07:36:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:36:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:39:36 --> Query error: Column 'notes' cannot be null - Invalid query: INSERT INTO `asset_value` (`asset_id`, `date`, `value`, `value_type`, `notes`) VALUES ('23', '2016-07-31', '1098000000', NULL, NULL)
ERROR - 2019-10-01 07:43:53 --> Severity: Notice --> Undefined index: asset_value/update_asset_value /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 07:43:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 07:43:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 10:06:34 --> Severity: Notice --> Undefined index: invoice/create /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 10:06:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 10:06:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 10:32:21 --> Severity: error --> Exception: Call to undefined method Contract_model::asset_detail() /var/www/html/aset/api/application/controllers/Invoice.php 63
ERROR - 2019-10-01 11:15:59 --> Severity: Notice --> Undefined index: invoice/issue /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-01 11:15:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 11:15:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-01 15:37:36 --> 404 Page Not Found: Payment/insert
