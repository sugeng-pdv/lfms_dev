<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 01:42:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 01:42:47 --> Unable to connect to the database
ERROR - 2020-07-06 01:56:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 01:56:29 --> Unable to connect to the database
ERROR - 2020-07-06 01:56:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 01:56:29 --> Unable to connect to the database
ERROR - 2020-07-06 01:56:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 01:56:33 --> Unable to connect to the database
ERROR - 2020-07-06 02:06:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 02:06:52 --> Unable to connect to the database
ERROR - 2020-07-06 02:06:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 02:06:53 --> Unable to connect to the database
ERROR - 2020-07-06 02:06:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 02:06:58 --> Unable to connect to the database
ERROR - 2020-07-06 02:07:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 02:07:00 --> Unable to connect to the database
ERROR - 2020-07-06 03:02:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:02:50 --> Unable to connect to the database
ERROR - 2020-07-06 03:44:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:44:06 --> Unable to connect to the database
ERROR - 2020-07-06 03:44:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:44:14 --> Unable to connect to the database
ERROR - 2020-07-06 03:45:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:45:09 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:13 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:13 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:13 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:13 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:56 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:56 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:56 --> Unable to connect to the database
ERROR - 2020-07-06 03:46:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 03:46:56 --> Unable to connect to the database
ERROR - 2020-07-06 04:51:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:51:58 --> Unable to connect to the database
ERROR - 2020-07-06 04:51:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:51:58 --> Unable to connect to the database
ERROR - 2020-07-06 04:52:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:52:04 --> Unable to connect to the database
ERROR - 2020-07-06 04:52:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:52:55 --> Unable to connect to the database
ERROR - 2020-07-06 04:52:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:52:56 --> Unable to connect to the database
ERROR - 2020-07-06 04:52:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:52:59 --> Unable to connect to the database
ERROR - 2020-07-06 04:53:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:53:23 --> Unable to connect to the database
ERROR - 2020-07-06 04:55:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 04:55:51 --> Unable to connect to the database
ERROR - 2020-07-06 06:09:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 06:09:49 --> Unable to connect to the database
ERROR - 2020-07-06 06:09:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 06:09:53 --> Unable to connect to the database
ERROR - 2020-07-06 07:21:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 07:21:56 --> Unable to connect to the database
ERROR - 2020-07-06 08:51:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 08:51:48 --> Unable to connect to the database
ERROR - 2020-07-06 08:51:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 08:51:48 --> Unable to connect to the database
ERROR - 2020-07-06 10:02:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:02:36 --> Unable to connect to the database
ERROR - 2020-07-06 10:03:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:03:17 --> Unable to connect to the database
ERROR - 2020-07-06 10:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:03:40 --> Unable to connect to the database
ERROR - 2020-07-06 10:05:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:05:06 --> Unable to connect to the database
ERROR - 2020-07-06 10:05:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:05:06 --> Unable to connect to the database
ERROR - 2020-07-06 10:05:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:05:06 --> Unable to connect to the database
ERROR - 2020-07-06 10:05:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:05:08 --> Unable to connect to the database
ERROR - 2020-07-06 10:06:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:06:54 --> Unable to connect to the database
ERROR - 2020-07-06 10:06:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:06:55 --> Unable to connect to the database
ERROR - 2020-07-06 10:06:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:06:56 --> Unable to connect to the database
ERROR - 2020-07-06 10:06:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:06:56 --> Unable to connect to the database
ERROR - 2020-07-06 10:08:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:08:15 --> Unable to connect to the database
ERROR - 2020-07-06 10:08:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:08:15 --> Unable to connect to the database
ERROR - 2020-07-06 10:08:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:08:16 --> Unable to connect to the database
ERROR - 2020-07-06 10:08:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:08:16 --> Unable to connect to the database
ERROR - 2020-07-06 10:51:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 10:51:56 --> Unable to connect to the database
ERROR - 2020-07-06 12:01:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 12:01:57 --> Unable to connect to the database
ERROR - 2020-07-06 12:32:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 12:32:10 --> Unable to connect to the database
ERROR - 2020-07-06 13:29:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 13:29:10 --> Unable to connect to the database
ERROR - 2020-07-06 15:12:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 15:12:10 --> Unable to connect to the database
ERROR - 2020-07-06 16:00:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:00:05 --> Unable to connect to the database
ERROR - 2020-07-06 16:00:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:00:05 --> Unable to connect to the database
ERROR - 2020-07-06 16:00:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:00:12 --> Unable to connect to the database
ERROR - 2020-07-06 16:00:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:00:21 --> Unable to connect to the database
ERROR - 2020-07-06 16:00:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:00:29 --> Unable to connect to the database
ERROR - 2020-07-06 16:04:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:04:58 --> Unable to connect to the database
ERROR - 2020-07-06 16:04:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:04:59 --> Unable to connect to the database
ERROR - 2020-07-06 16:05:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:05:00 --> Unable to connect to the database
ERROR - 2020-07-06 16:21:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 16:21:37 --> Unable to connect to the database
ERROR - 2020-07-06 17:13:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:13:56 --> Unable to connect to the database
ERROR - 2020-07-06 17:13:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:13:56 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:02 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:14 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:14 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:20 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:20 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:24 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:29 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:36 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:37 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:39 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:52 --> Unable to connect to the database
ERROR - 2020-07-06 17:14:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 17:14:52 --> Unable to connect to the database
ERROR - 2020-07-06 19:03:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 19:03:13 --> Unable to connect to the database
ERROR - 2020-07-06 21:03:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-06 21:03:29 --> Unable to connect to the database
