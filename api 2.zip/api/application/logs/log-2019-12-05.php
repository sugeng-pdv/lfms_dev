<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-05 03:53:06 --> Severity: Notice --> Undefined index: v /var/www/html/aset/api/application/controllers/Public_asset.php 344
ERROR - 2019-12-05 11:03:35 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-05 11:03:54 --> 404 Page Not Found: Public/asset
