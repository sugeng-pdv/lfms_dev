<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 20:23:37 --> Severity: Notice --> Undefined property: Auth::$Employee_model /var/www/html/d7c/development/api/application/controllers/Auth.php 101
ERROR - 2020-08-26 20:23:37 --> Severity: error --> Exception: Call to a member function employee_role() on null /var/www/html/d7c/development/api/application/controllers/Auth.php 101
ERROR - 2020-08-26 20:57:53 --> Severity: Notice --> Undefined property: stdClass::$id /var/www/html/d7c/development/api/application/controllers/Auth.php 102
ERROR - 2020-08-26 21:04:04 --> Severity: Notice --> Undefined property: stdClass::$id /var/www/html/d7c/development/api/application/controllers/Auth.php 110
ERROR - 2020-08-26 21:04:04 --> Query error: Column 'employee_id' cannot be null - Invalid query: INSERT INTO `employee_token` (`jwt_uid`, `employee_id`, `issued`) VALUES ('5f466bd484a49', NULL, 1598450644)
