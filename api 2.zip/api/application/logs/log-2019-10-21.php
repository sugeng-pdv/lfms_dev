<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-21 02:11:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:12:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:13:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:31:05 --> Severity: Notice --> Trying to get property 'ready' of non-object /var/www/html/aset/api/application/controllers/Auth.php 65
ERROR - 2019-10-21 02:33:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:33:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:34:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:35:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:39:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:40:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:41:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:42:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:42:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:43:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:43:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:43:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /var/www/html/aset/api/application/controllers/Dashboard.php 184
ERROR - 2019-10-21 02:56:35 --> Severity: Notice --> Undefined variable: result /var/www/html/aset/api/application/controllers/Auth.php 87
ERROR - 2019-10-21 07:12:30 --> Severity: Notice --> Undefined property: Auth::$instance /var/www/html/aset/api/application/controllers/Auth.php 28
ERROR - 2019-10-21 07:12:30 --> Severity: Notice --> Trying to get property 'output' of non-object /var/www/html/aset/api/application/controllers/Auth.php 28
ERROR - 2019-10-21 07:12:30 --> Severity: error --> Exception: Call to a member function set_status_header() on null /var/www/html/aset/api/application/controllers/Auth.php 28
