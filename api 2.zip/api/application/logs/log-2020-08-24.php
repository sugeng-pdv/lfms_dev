<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-24 20:39:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_d7c_development'@'localhost' (using password: YES) /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:39:30 --> Unable to connect to the database
ERROR - 2020-08-24 20:40:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_d7c_development'@'localhost' (using password: YES) /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:40:39 --> Unable to connect to the database
ERROR - 2020-08-24 20:41:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_d7c_development'@'localhost' (using password: YES) /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:41:34 --> Unable to connect to the database
ERROR - 2020-08-24 20:42:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_d7c_development'@'localhost' (using password: YES) /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:42:38 --> Unable to connect to the database
ERROR - 2020-08-24 20:57:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'lman_d7c_development'@'%' to database 'lman_d7c_development' /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:57:29 --> Unable to connect to the database
ERROR - 2020-08-24 20:57:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user 'lman_d7c_development'@'%' to database 'lman_d7c_temp' /var/www/html/d7c/development/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-08-24 20:57:56 --> Unable to connect to the database
ERROR - 2020-08-24 22:53:18 --> Severity: Warning --> include_once(/var/www/html/d7c/development/api/application//third_party/Requests/Requests.php): failed to open stream: No such file or directory /var/www/html/d7c/development/api/application/helpers/pwd_helper.php 12
ERROR - 2020-08-24 22:53:18 --> Severity: Warning --> include_once(): Failed opening '/var/www/html/d7c/development/api/application//third_party/Requests/Requests.php' for inclusion (include_path='.:/usr/share/php') /var/www/html/d7c/development/api/application/helpers/pwd_helper.php 12
ERROR - 2020-08-24 22:53:18 --> Severity: error --> Exception: Class 'Requests' not found /var/www/html/d7c/development/api/application/helpers/pwd_helper.php 15
ERROR - 2020-08-24 22:54:02 --> Severity: Notice --> Undefined property: Auth::$Employee_model /var/www/html/d7c/development/api/application/controllers/Auth.php 101
ERROR - 2020-08-24 22:54:02 --> Severity: error --> Exception: Call to a member function employee_role() on null /var/www/html/d7c/development/api/application/controllers/Auth.php 101
