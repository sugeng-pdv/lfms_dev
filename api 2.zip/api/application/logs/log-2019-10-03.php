<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-03 10:02:07 --> 404 Page Not Found: Asset_value/update_asset_value
ERROR - 2019-10-03 10:16:42 --> 404 Page Not Found: Asset_value/add_asset_value
ERROR - 2019-10-03 14:41:06 --> 404 Page Not Found: Asset_duty/get
ERROR - 2019-10-03 14:41:17 --> 404 Page Not Found: Asset_duty/get
ERROR - 2019-10-03 14:55:32 --> Severity: Notice --> Undefined property: Duty::$Facility_model /var/www/html/aset/api/application/controllers/Duty.php 288
ERROR - 2019-10-03 14:55:32 --> Severity: error --> Exception: Call to a member function get_type() on null /var/www/html/aset/api/application/controllers/Duty.php 288
ERROR - 2019-10-03 15:02:54 --> Severity: Notice --> Undefined index: duty/add /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-03 15:02:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-03 15:02:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
