<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 03:07:51 --> Severity: error --> Exception: Call to undefined method Public_asset::get_class() /var/www/html/aset/api/application/controllers/Public_asset.php 24
ERROR - 2019-12-03 03:16:44 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 03:22:22 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 03:23:48 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 03:24:24 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 03:24:25 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 15:40:08 --> 404 Page Not Found: Public/aset
ERROR - 2019-12-03 15:40:17 --> 404 Page Not Found: Public_aset/get_top_category
ERROR - 2019-12-03 15:40:34 --> 404 Page Not Found: Public/asset
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 472
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 478
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 472
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 478
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 472
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 478
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 472
ERROR - 2019-12-03 15:58:03 --> Severity: Warning --> A non-numeric value encountered /var/www/html/aset/api/application/controllers/Public_asset.php 478
