<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-02 08:43:07 --> 404 Page Not Found: Asset/delete_video
