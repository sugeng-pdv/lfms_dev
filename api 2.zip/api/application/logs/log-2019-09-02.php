<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-02 04:23:38 --> Severity: Notice --> Undefined property: Asset::$Asset_item_model /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-02 04:23:38 --> Severity: error --> Exception: Call to a member function get_by_asset() on null /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-02 04:23:47 --> Severity: Notice --> Undefined property: Asset::$Asset_item_model /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-02 04:23:47 --> Severity: error --> Exception: Call to a member function get_by_asset() on null /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-02 04:24:25 --> Query error: Table 'lman_asset_service.structure_item' doesn't exist - Invalid query: SELECT *
FROM `structure_item`
WHERE `asset_id` = '23'
ORDER BY `id` ASC
