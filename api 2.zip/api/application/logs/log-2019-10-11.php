<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-11 11:03:14 --> Query error: execute command denied to user 'lman_ais'@'%' for routine 'lman_asset_service.CountAssetByHandoverYear' - Invalid query: CALL CountAssetByHandoverYear(2015)
ERROR - 2019-10-11 11:04:17 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL CountAssetByHandoverYear(2016)
ERROR - 2019-10-11 11:14:57 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::next_result() /var/www/html/aset/api/application/models/Dashboard_model.php 16
ERROR - 2019-10-11 11:17:14 --> Severity: Notice --> Trying to get property 'jumlah_aset' of non-object /var/www/html/aset/api/application/models/Dashboard_model.php 19
ERROR - 2019-10-11 11:17:14 --> Severity: Notice --> Trying to get property 'jumlah_aset' of non-object /var/www/html/aset/api/application/models/Dashboard_model.php 19
ERROR - 2019-10-11 11:17:14 --> Severity: Notice --> Trying to get property 'jumlah_aset' of non-object /var/www/html/aset/api/application/models/Dashboard_model.php 19
ERROR - 2019-10-11 11:17:14 --> Severity: Notice --> Trying to get property 'jumlah_aset' of non-object /var/www/html/aset/api/application/models/Dashboard_model.php 19
ERROR - 2019-10-11 11:17:14 --> Severity: Notice --> Trying to get property 'jumlah_aset' of non-object /var/www/html/aset/api/application/models/Dashboard_model.php 19
