<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-14 15:15:47 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 330
ERROR - 2020-08-14 15:15:47 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 331
ERROR - 2020-08-14 15:15:47 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 330
ERROR - 2020-08-14 15:15:47 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 331
