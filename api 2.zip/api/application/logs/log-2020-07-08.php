<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 00:06:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 00:06:50 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:25 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:26 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:27 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:35 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:35 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:38 --> Unable to connect to the database
ERROR - 2020-07-08 02:03:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 02:03:39 --> Unable to connect to the database
ERROR - 2020-07-08 03:14:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:14:18 --> Unable to connect to the database
ERROR - 2020-07-08 03:14:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:14:20 --> Unable to connect to the database
ERROR - 2020-07-08 03:32:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:32:05 --> Unable to connect to the database
ERROR - 2020-07-08 03:32:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:32:09 --> Unable to connect to the database
ERROR - 2020-07-08 03:32:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:32:09 --> Unable to connect to the database
ERROR - 2020-07-08 03:32:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:32:15 --> Unable to connect to the database
ERROR - 2020-07-08 03:32:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:32:15 --> Unable to connect to the database
ERROR - 2020-07-08 03:37:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-08 03:37:25 --> Unable to connect to the database
ERROR - 2020-07-08 04:55:25 --> Query error: execute command denied to user 'lman_d7c'@'%' for routine 'lman_d7c.CountAssetByHandoverYear' - Invalid query: CALL CountAssetByHandoverYear(2015)
ERROR - 2020-07-08 04:55:38 --> Query error: execute command denied to user 'lman_d7c'@'%' for routine 'lman_d7c.CountAssetByHandoverYear' - Invalid query: CALL CountAssetByHandoverYear(2015)
