<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-13 07:05:49 --> 404 Page Not Found: Public/lf
