<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-28 02:10:06 --> Severity: Notice --> Undefined index: asset/add_land_document /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-28 02:10:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-28 02:10:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:16 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:27:28 --> Severity: Notice --> Trying to get property 'total_surface_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 271
ERROR - 2019-10-28 02:33:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/aset/api/application/controllers/Asset.php 264
ERROR - 2019-10-28 02:53:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`land_document`, CONSTRAINT `land_document_ibfk_1` FOREIGN KEY (`land_id`) REFERENCES `land` (`id`)) - Invalid query: INSERT INTO `land_document` (`land_id`, `doc_name`, `s3_bucket`, `s3_object`) VALUES ('undefined', 'IMB', 's3-lman', 'DOKUMEN-TANAH/2019/10/28/BZe-2-okt-2019---progress-pembangunan-asset-information-system.pdf')
ERROR - 2019-10-28 02:58:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`land_document`, CONSTRAINT `land_document_ibfk_1` FOREIGN KEY (`land_id`) REFERENCES `land` (`id`)) - Invalid query: INSERT INTO `land_document` (`land_id`, `doc_name`, `s3_bucket`, `s3_object`) VALUES ('undefined', 'IMB Hal 1', 's3-lman', 'DOKUMEN-TANAH/2019/10/28/p5s-2-okt-2019---progress-pembangunan-asset-information-system.pdf')
ERROR - 2019-10-28 03:04:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`structure_document`, CONSTRAINT `structure_document_ibfk_1` FOREIGN KEY (`structure_id`) REFERENCES `structure` (`id`)) - Invalid query: INSERT INTO `structure_document` (`structure_id`, `doc_name`, `s3_bucket`, `s3_object`) VALUES ('undefined', 'IMB Hal 1', 's3-lman', 'DOKUMEN-BANGUNAN/2019/10/28/3dn-2-okt-2019---progress-pembangunan-asset-information-system.pdf')
ERROR - 2019-10-28 03:49:33 --> Severity: Notice --> Undefined variable: total_luas_tanah /var/www/html/aset/api/application/controllers/Asset.php 280
ERROR - 2019-10-28 07:06:48 --> 404 Page Not Found: Auth/authority_list
ERROR - 2019-10-28 07:26:22 --> 404 Page Not Found: Auth/login_json
ERROR - 2019-10-28 07:26:30 --> 404 Page Not Found: Auth/login_json
ERROR - 2019-10-28 07:30:18 --> 404 Page Not Found: Employee/add
ERROR - 2019-10-28 07:30:41 --> 404 Page Not Found: Employee/add
ERROR - 2019-10-28 07:31:11 --> 404 Page Not Found: Employee/add
ERROR - 2019-10-28 07:31:45 --> 404 Page Not Found: Employee/add
ERROR - 2019-10-28 10:13:30 --> Severity: Notice --> Array to string conversion /var/www/html/aset/api/application/controllers/Dashboard.php 104
