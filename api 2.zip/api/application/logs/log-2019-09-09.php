<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 06:46:23 --> Severity: Notice --> Trying to get property 'total_structure_area' of non-object /var/www/html/aset/api/application/controllers/Asset.php 232
ERROR - 2019-09-09 09:10:23 --> 404 Page Not Found: Asset/update_structure_data
ERROR - 2019-09-09 09:16:37 --> Severity: Notice --> Undefined index: asset/update_structure_data /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-09 09:16:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-09 09:16:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
