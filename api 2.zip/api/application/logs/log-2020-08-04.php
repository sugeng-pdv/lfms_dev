<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-04 10:30:07 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 330
ERROR - 2020-08-04 10:30:07 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 331
ERROR - 2020-08-04 10:55:05 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 330
ERROR - 2020-08-04 10:55:05 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 331
