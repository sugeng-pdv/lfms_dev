<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-14 09:09:56 --> 404 Page Not Found: Public/lf
ERROR - 2020-01-14 09:10:00 --> 404 Page Not Found: Public/lf
ERROR - 2020-01-14 09:10:14 --> 404 Page Not Found: Public/lf
