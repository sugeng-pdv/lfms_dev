<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 02:17:36 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Public_asset.php 481
ERROR - 2019-12-04 02:17:36 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Public_asset.php 481
ERROR - 2019-12-04 02:17:36 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Public_asset.php 481
ERROR - 2019-12-04 02:17:36 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Public_asset.php 481
ERROR - 2019-12-04 02:26:13 --> Severity: error --> Exception: Call to undefined function tataDataAset() /var/www/html/aset/api/application/controllers/Public_asset.php 482
