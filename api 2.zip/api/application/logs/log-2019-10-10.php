<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-10 05:05:48 --> Severity: Notice --> Undefined index: dashboard /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-10 05:05:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-10 05:05:48 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-10 05:16:13 --> Severity: Notice --> Undefined property: Dashboard::$Asset_origin_model /var/www/html/aset/api/application/controllers/Dashboard.php 25
ERROR - 2019-10-10 05:16:13 --> Severity: error --> Exception: Call to a member function get() on null /var/www/html/aset/api/application/controllers/Dashboard.php 25
