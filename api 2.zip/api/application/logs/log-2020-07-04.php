<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-04 17:23:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 17:23:37 --> Unable to connect to the database
ERROR - 2020-07-04 18:23:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 18:23:51 --> Unable to connect to the database
ERROR - 2020-07-04 19:54:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 19:54:27 --> Unable to connect to the database
ERROR - 2020-07-04 21:14:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 21:14:49 --> Unable to connect to the database
ERROR - 2020-07-04 22:15:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 22:15:14 --> Unable to connect to the database
ERROR - 2020-07-04 23:05:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 23:05:37 --> Unable to connect to the database
ERROR - 2020-07-04 23:15:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 23:15:42 --> Unable to connect to the database
ERROR - 2020-07-04 23:55:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-04 23:55:24 --> Unable to connect to the database
