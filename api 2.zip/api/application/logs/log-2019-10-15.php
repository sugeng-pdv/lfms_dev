<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-15 02:57:16 --> Severity: Notice --> Undefined index: contract /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-15 02:57:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-15 02:57:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-15 02:58:43 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Contract.php 226
ERROR - 2019-10-15 09:25:44 --> Severity: Notice --> Undefined index: asset /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-15 09:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-15 09:25:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
