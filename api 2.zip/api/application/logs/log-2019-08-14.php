<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-14 07:22:54 --> 404 Page Not Found: Asset/detail
ERROR - 2019-08-14 07:23:09 --> Severity: Notice --> Undefined property: Access_control::$input /var/www/html/aset/api/application/libraries/Access_control.php 19
ERROR - 2019-08-14 07:23:09 --> Severity: error --> Exception: Call to a member function get_request_header() on null /var/www/html/aset/api/application/libraries/Access_control.php 19
ERROR - 2019-08-14 07:26:15 --> Severity: error --> Exception: Unexpected control character found /var/www/html/aset/api/application/libraries/JWT.php 358
ERROR - 2019-08-14 07:27:15 --> Severity: error --> Exception: Unexpected control character found /var/www/html/aset/api/application/libraries/JWT.php 358
ERROR - 2019-08-14 07:29:07 --> Severity: error --> Exception: Unexpected control character found /var/www/html/aset/api/application/libraries/JWT.php 358
ERROR - 2019-08-14 07:36:56 --> Severity: error --> Exception: Call to undefined function getBearerToken() /var/www/html/aset/api/application/libraries/Access_control.php 27
ERROR - 2019-08-14 07:37:13 --> Severity: error --> Exception: Call to undefined function getAuthorizationHeader() /var/www/html/aset/api/application/libraries/Access_control.php 85
ERROR - 2019-08-14 08:16:50 --> Severity: error --> Exception: Signature verification failed /var/www/html/aset/api/application/libraries/JWT.php 112
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Undefined variable: decoded /var/www/html/aset/api/application/libraries/Access_control.php 41
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Trying to get property 'userid' of non-object /var/www/html/aset/api/application/libraries/Access_control.php 41
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Undefined variable: decoded /var/www/html/aset/api/application/libraries/Access_control.php 42
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Trying to get property 'username' of non-object /var/www/html/aset/api/application/libraries/Access_control.php 42
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Undefined variable: decoded /var/www/html/aset/api/application/libraries/Access_control.php 43
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Trying to get property 'name' of non-object /var/www/html/aset/api/application/libraries/Access_control.php 43
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Undefined variable: decoded /var/www/html/aset/api/application/libraries/Access_control.php 44
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Trying to get property 'role' of non-object /var/www/html/aset/api/application/libraries/Access_control.php 44
ERROR - 2019-08-14 08:28:39 --> Severity: Notice --> Constant ROLE already defined /var/www/html/aset/api/application/libraries/Access_control.php 44
