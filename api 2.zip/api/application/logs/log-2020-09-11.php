<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'id' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 140
ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'name' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 141
ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'link' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 142
ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'id' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 140
ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'name' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 141
ERROR - 2020-09-11 07:53:38 --> Severity: Notice --> Trying to get property 'link' of non-object /var/www/html/d7c/development/api/application/controllers/Menu.php 142
ERROR - 2020-09-11 07:55:53 --> Severity: error --> Exception: syntax error, unexpected 'array_push' (T_STRING), expecting ';' /var/www/html/d7c/development/api/application/controllers/Menu.php 138
ERROR - 2020-09-11 12:15:19 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/d7c/development/api/system/core/Loader.php 348
ERROR - 2020-09-11 12:16:20 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/d7c/development/api/system/core/Loader.php 348
ERROR - 2020-09-11 13:22:01 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/d7c/development/api/system/core/Loader.php 348
ERROR - 2020-09-11 14:10:58 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `acl_user`
WHERE `status` = 'ACTIVE'
ORDER BY `name` ASC, `id` ASC
ERROR - 2020-09-11 14:11:18 --> Severity: Notice --> Undefined property: stdClass::$parent /var/www/html/d7c/development/api/application/controllers/User.php 48
ERROR - 2020-09-11 14:11:18 --> Severity: Notice --> Undefined property: stdClass::$link /var/www/html/d7c/development/api/application/controllers/User.php 52
ERROR - 2020-09-11 14:47:01 --> 404 Page Not Found: User/tree
ERROR - 2020-09-11 14:50:16 --> 404 Page Not Found: User/tree
ERROR - 2020-09-11 14:50:28 --> 404 Page Not Found: User/tree
ERROR - 2020-09-11 14:56:39 --> 404 Page Not Found: User/tree
ERROR - 2020-09-11 14:57:02 --> 404 Page Not Found: User/tree
