<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-29 04:12:27 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) /var/www/html/aset/api/application/controllers/Asset.php 464
ERROR - 2019-08-29 04:12:35 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting function (T_FUNCTION) or const (T_CONST) /var/www/html/aset/api/application/controllers/Asset.php 464
