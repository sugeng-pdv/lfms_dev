<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-01 02:02:03 --> Severity: Notice --> Undefined index: UPLOAD_FILE /var/www/html/aset/api/application/libraries/Access_control.php 33
ERROR - 2019-08-01 02:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 35
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> Use of undefined constant SYSTEM_TIME - assumed 'SYSTEM_TIME' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> Use of undefined constant SYSTEM_TIME - assumed 'SYSTEM_TIME' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> Use of undefined constant SYSTEM_TIME - assumed 'SYSTEM_TIME' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 02:03:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /var/www/html/aset/api/application/controllers/File.php 75
ERROR - 2019-08-01 08:34:36 --> 404 Page Not Found: Asset/delete_image
