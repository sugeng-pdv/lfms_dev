<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-11 04:08:26 --> Severity: Notice --> Undefined variable: asset_id /var/www/html/aset/api/application/controllers/Asset.php 1322
ERROR - 2019-09-11 09:50:22 --> Severity: Notice --> Undefined index: business_case/add_document /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-11 09:50:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-11 09:50:22 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-11 09:50:58 --> Severity: error --> Exception: Call to undefined method Business_case_model::insert_document() /var/www/html/aset/api/application/controllers/Business_case.php 153
ERROR - 2019-09-11 10:04:31 --> Severity: Notice --> Undefined index: operational_activity/add_document /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-11 10:04:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-11 10:04:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
