<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-26 06:24:58 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 29
ERROR - 2019-08-26 06:24:58 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 42
ERROR - 2019-08-26 06:24:58 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 44
ERROR - 2019-08-26 06:24:58 --> Severity: Notice --> Undefined variable: city_id /var/www/html/aset/api/application/models/Asset_model.php 44
ERROR - 2019-08-26 06:25:07 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 29
ERROR - 2019-08-26 06:25:07 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 42
ERROR - 2019-08-26 06:25:07 --> Severity: Notice --> Undefined variable: province_id /var/www/html/aset/api/application/models/Asset_model.php 44
ERROR - 2019-08-26 06:25:07 --> Severity: Notice --> Undefined variable: city_id /var/www/html/aset/api/application/models/Asset_model.php 44
