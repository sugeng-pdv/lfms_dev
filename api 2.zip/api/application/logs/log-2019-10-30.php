<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-30 04:40:29 --> Query error: Duplicate entry 'developer@lman.site' for key 'email' - Invalid query: INSERT INTO `employee` (`email`, `nip_npp`, `pwd`, `salt`, `version`, `name`) VALUES ('developer@lman.site', '000000000000000000', '$2y$12$aGT4bZI3bhWeNmIwE5XK.unNHQdJxoYC70hs6/d4BDnCEUQrCuP/C', 'wzBXNZ4UcsfghWIJr76bKxApvVT9l8RkdYGiDS5QPm', '1', 'User Developer')
