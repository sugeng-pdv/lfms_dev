<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-26 08:34:34 --> 404 Page Not Found: Aset/api
ERROR - 2019-12-26 08:34:55 --> 404 Page Not Found: Aset/api
ERROR - 2019-12-26 08:35:17 --> 404 Page Not Found: Aset/api
ERROR - 2019-12-26 08:35:22 --> 404 Page Not Found: Aset/api
