<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-19 04:27:32 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Asset.php 250
ERROR - 2019-08-19 04:40:46 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Asset.php 250
ERROR - 2019-08-19 09:30:13 --> Severity: error --> Exception: Call to undefined method stdClass::result() /var/www/html/aset/api/application/models/Employee_model.php 35
ERROR - 2019-08-19 09:32:49 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/aset/api/application/models/Employee_model.php 35
ERROR - 2019-08-19 09:33:45 --> Severity: error --> Exception: Call to a member function result() on boolean /var/www/html/aset/api/application/models/Employee_model.php 35
ERROR - 2019-08-19 09:49:24 --> Severity: Warning --> Use of undefined constant ROLE - assumed 'ROLE' (this will throw an Error in a future version of PHP) /var/www/html/aset/api/application/controllers/Asset.php 250
