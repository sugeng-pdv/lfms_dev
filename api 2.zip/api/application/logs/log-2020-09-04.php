<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-04 14:14:17 --> Severity: error --> Exception: Call to undefined method Role::post() /var/www/html/d7c/development/api/application/controllers/Role.php 29
