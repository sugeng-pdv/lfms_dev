<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-05 05:50:42 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
ERROR - 2020-05-05 05:50:42 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
ERROR - 2020-05-05 05:51:25 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
ERROR - 2020-05-05 05:51:25 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
ERROR - 2020-05-05 05:53:11 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
ERROR - 2020-05-05 05:53:11 --> Severity: Notice --> Trying to get property 's3_bucket' of non-object /var/www/html/aset/api/application/controllers/Public_asset.php 159
