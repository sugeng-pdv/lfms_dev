<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-10 02:34:31 --> 404 Page Not Found: Asset/update_land_data
ERROR - 2019-09-10 02:49:41 --> Severity: Notice --> Undefined index: asset/update_land_data /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-10 02:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-10 02:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-10 10:02:26 --> Query error: Column 'object' cannot be null - Invalid query: INSERT INTO `operational_activity` (`asset_id`, `type`, `date`, `by`, `object`, `cost`, `status`, `notes`) VALUES ('23', 1, '2019-08-29', 'Paijo', NULL, '2690000', 'Selesai', 'Contoh catatan')
ERROR - 2019-09-10 10:12:26 --> Severity: Notice --> Undefined index: operational_activity/update_security /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-09-10 10:12:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-09-10 10:12:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
