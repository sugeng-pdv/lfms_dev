<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-29 03:48:03 --> Severity: Notice --> Undefined index: asset/update_basic_data /var/www/html/aset/api/application/libraries/Access_control.php 33
ERROR - 2019-07-29 03:48:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 35
ERROR - 2019-07-29 03:48:57 --> Could not find the language line "form_validation_kategori"
