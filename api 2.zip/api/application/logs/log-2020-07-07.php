<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 00:34:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:34:00 --> Unable to connect to the database
ERROR - 2020-07-07 00:44:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:44:04 --> Unable to connect to the database
ERROR - 2020-07-07 00:55:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:55:51 --> Unable to connect to the database
ERROR - 2020-07-07 00:55:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:55:51 --> Unable to connect to the database
ERROR - 2020-07-07 00:55:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:55:51 --> Unable to connect to the database
ERROR - 2020-07-07 00:55:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:55:51 --> Unable to connect to the database
ERROR - 2020-07-07 00:56:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:56:00 --> Unable to connect to the database
ERROR - 2020-07-07 00:56:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:56:00 --> Unable to connect to the database
ERROR - 2020-07-07 00:56:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:56:00 --> Unable to connect to the database
ERROR - 2020-07-07 00:56:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 00:56:00 --> Unable to connect to the database
ERROR - 2020-07-07 01:25:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 01:25:11 --> Unable to connect to the database
ERROR - 2020-07-07 01:25:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 01:25:11 --> Unable to connect to the database
ERROR - 2020-07-07 01:25:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 01:25:11 --> Unable to connect to the database
ERROR - 2020-07-07 01:25:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 01:25:11 --> Unable to connect to the database
ERROR - 2020-07-07 04:57:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 04:57:41 --> Unable to connect to the database
ERROR - 2020-07-07 04:57:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 04:57:42 --> Unable to connect to the database
ERROR - 2020-07-07 04:57:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 04:57:49 --> Unable to connect to the database
ERROR - 2020-07-07 04:57:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 04:57:50 --> Unable to connect to the database
ERROR - 2020-07-07 04:57:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 04:57:54 --> Unable to connect to the database
ERROR - 2020-07-07 05:00:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 05:00:30 --> Unable to connect to the database
ERROR - 2020-07-07 05:00:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 05:00:31 --> Unable to connect to the database
ERROR - 2020-07-07 05:51:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 05:51:36 --> Unable to connect to the database
ERROR - 2020-07-07 06:09:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:09:49 --> Unable to connect to the database
ERROR - 2020-07-07 06:09:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:09:51 --> Unable to connect to the database
ERROR - 2020-07-07 06:09:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:09:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:09:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:09:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:09:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:09:57 --> Unable to connect to the database
ERROR - 2020-07-07 06:10:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:10:03 --> Unable to connect to the database
ERROR - 2020-07-07 06:10:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:10:05 --> Unable to connect to the database
ERROR - 2020-07-07 06:10:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:10:07 --> Unable to connect to the database
ERROR - 2020-07-07 06:10:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:10:33 --> Unable to connect to the database
ERROR - 2020-07-07 06:10:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:10:33 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:05 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:05 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:07 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:20 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:20 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:30 --> Unable to connect to the database
ERROR - 2020-07-07 06:12:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:12:30 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:00 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:01 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:02 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:18:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:18:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:42:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:42:30 --> Unable to connect to the database
ERROR - 2020-07-07 06:42:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:42:30 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:24 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:46 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:46 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:46 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:46 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:47 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:47 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:47 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:47 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:58 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:58 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:58 --> Unable to connect to the database
ERROR - 2020-07-07 06:52:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:52:58 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:04 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:04 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:04 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:04 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:18 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:18 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:18 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:18 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:54:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:54:56 --> Unable to connect to the database
ERROR - 2020-07-07 06:55:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:55:06 --> Unable to connect to the database
ERROR - 2020-07-07 06:55:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:55:07 --> Unable to connect to the database
ERROR - 2020-07-07 06:55:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:55:09 --> Unable to connect to the database
ERROR - 2020-07-07 06:55:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:55:20 --> Unable to connect to the database
ERROR - 2020-07-07 06:55:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:55:20 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:51 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:51 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:54 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:55 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:59 --> Unable to connect to the database
ERROR - 2020-07-07 06:57:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:57:59 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:01 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:08 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:10 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:10 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:10 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:11 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:11 --> Unable to connect to the database
ERROR - 2020-07-07 06:58:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 06:58:11 --> Unable to connect to the database
ERROR - 2020-07-07 07:00:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:00:33 --> Unable to connect to the database
ERROR - 2020-07-07 07:00:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:00:34 --> Unable to connect to the database
ERROR - 2020-07-07 07:04:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:04:35 --> Unable to connect to the database
ERROR - 2020-07-07 07:04:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:04:35 --> Unable to connect to the database
ERROR - 2020-07-07 07:04:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:04:35 --> Unable to connect to the database
ERROR - 2020-07-07 07:18:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:18:00 --> Unable to connect to the database
ERROR - 2020-07-07 07:32:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:32:11 --> Unable to connect to the database
ERROR - 2020-07-07 07:52:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 07:52:20 --> Unable to connect to the database
ERROR - 2020-07-07 08:52:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 08:52:45 --> Unable to connect to the database
ERROR - 2020-07-07 09:13:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:13:20 --> Unable to connect to the database
ERROR - 2020-07-07 09:23:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:23:21 --> Unable to connect to the database
ERROR - 2020-07-07 09:29:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:29:38 --> Unable to connect to the database
ERROR - 2020-07-07 09:29:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:29:38 --> Unable to connect to the database
ERROR - 2020-07-07 09:29:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:29:40 --> Unable to connect to the database
ERROR - 2020-07-07 09:43:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:43:43 --> Unable to connect to the database
ERROR - 2020-07-07 09:44:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 09:44:21 --> Unable to connect to the database
ERROR - 2020-07-07 10:03:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 10:03:23 --> Unable to connect to the database
ERROR - 2020-07-07 10:03:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 10:03:27 --> Unable to connect to the database
ERROR - 2020-07-07 11:03:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 11:03:20 --> Unable to connect to the database
ERROR - 2020-07-07 14:14:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 14:14:08 --> Unable to connect to the database
ERROR - 2020-07-07 14:14:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 14:14:14 --> Unable to connect to the database
ERROR - 2020-07-07 14:14:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 14:14:17 --> Unable to connect to the database
ERROR - 2020-07-07 15:14:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 15:14:04 --> Unable to connect to the database
ERROR - 2020-07-07 15:54:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 15:54:02 --> Unable to connect to the database
ERROR - 2020-07-07 18:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 18:10:02 --> Unable to connect to the database
ERROR - 2020-07-07 18:10:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 18:10:16 --> Unable to connect to the database
ERROR - 2020-07-07 18:10:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 18:10:17 --> Unable to connect to the database
ERROR - 2020-07-07 18:10:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 18:10:22 --> Unable to connect to the database
ERROR - 2020-07-07 18:10:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 18:10:25 --> Unable to connect to the database
ERROR - 2020-07-07 19:59:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 19:59:20 --> Unable to connect to the database
ERROR - 2020-07-07 21:51:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'lman_ais'@'localhost' (using password: YES) /var/www/html/aset/api/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-07 21:51:50 --> Unable to connect to the database
