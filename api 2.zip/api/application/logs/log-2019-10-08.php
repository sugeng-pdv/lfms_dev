<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-08 01:57:32 --> Severity: Notice --> Undefined index: invoice/get_invoice /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-08 01:57:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 01:57:32 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 01:57:43 --> Severity: Notice --> Undefined index: invoice/get_invoice /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-08 01:57:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 01:57:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 02:01:27 --> Severity: Notice --> Undefined property: stdClass::$start_date /var/www/html/aset/api/application/controllers/Invoice.php 60
ERROR - 2019-10-08 02:01:27 --> Severity: Notice --> Undefined property: stdClass::$start_date /var/www/html/aset/api/application/controllers/Invoice.php 61
ERROR - 2019-10-08 02:01:27 --> Severity: Notice --> Undefined property: stdClass::$asset_id /var/www/html/aset/api/application/controllers/Invoice.php 64
ERROR - 2019-10-08 02:01:27 --> Severity: Notice --> Undefined property: stdClass::$tenant_id /var/www/html/aset/api/application/controllers/Invoice.php 66
ERROR - 2019-10-08 02:01:27 --> Severity: error --> Exception: Call to undefined method Invoice_model::get_document() /var/www/html/aset/api/application/controllers/Invoice.php 71
ERROR - 2019-10-08 02:02:02 --> Severity: Notice --> Undefined property: stdClass::$asset_id /var/www/html/aset/api/application/controllers/Invoice.php 62
ERROR - 2019-10-08 02:02:02 --> Severity: Notice --> Undefined property: stdClass::$tenant_id /var/www/html/aset/api/application/controllers/Invoice.php 64
ERROR - 2019-10-08 02:02:02 --> Severity: error --> Exception: Call to undefined method Invoice_model::get_document() /var/www/html/aset/api/application/controllers/Invoice.php 69
ERROR - 2019-10-08 02:04:30 --> Severity: error --> Exception: Call to undefined method Invoice_model::get_document() /var/www/html/aset/api/application/controllers/Invoice.php 71
ERROR - 2019-10-08 02:05:08 --> Severity: Notice --> Undefined property: stdClass::$start_date /var/www/html/aset/api/application/controllers/Invoice.php 72
ERROR - 2019-10-08 02:05:08 --> Severity: Notice --> Undefined property: stdClass::$start_date /var/www/html/aset/api/application/controllers/Invoice.php 72
ERROR - 2019-10-08 02:05:08 --> Severity: Notice --> Undefined property: stdClass::$start_date /var/www/html/aset/api/application/controllers/Invoice.php 72
ERROR - 2019-10-08 02:08:16 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/aset/api/application/controllers/Invoice.php 57
ERROR - 2019-10-08 02:14:33 --> Severity: Notice --> Undefined property: stdClass::$contract_id /var/www/html/aset/api/application/controllers/Invoice.php 64
ERROR - 2019-10-08 02:14:33 --> Severity: Notice --> Undefined property: stdClass::$contract_id /var/www/html/aset/api/application/controllers/Invoice.php 64
ERROR - 2019-10-08 02:14:33 --> Severity: Notice --> Undefined property: stdClass::$contract_id /var/www/html/aset/api/application/controllers/Invoice.php 64
ERROR - 2019-10-08 07:16:57 --> 404 Page Not Found: Asset/check_asset_code01.01.2016.00017
ERROR - 2019-10-08 07:43:57 --> Severity: Notice --> Undefined variable: offset /var/www/html/aset/api/application/controllers/Invoice.php 135
ERROR - 2019-10-08 08:04:45 --> 404 Page Not Found: Contract/check_contract_code
ERROR - 2019-10-08 08:06:00 --> Severity: Notice --> Undefined property: Contract::$Contract_model /var/www/html/aset/api/application/controllers/Contract.php 755
ERROR - 2019-10-08 08:06:00 --> Severity: error --> Exception: Call to a member function detail_by_contract_number() on null /var/www/html/aset/api/application/controllers/Contract.php 755
ERROR - 2019-10-08 08:08:04 --> Severity: Notice --> Undefined property: Contract::$Contract_model /var/www/html/aset/api/application/controllers/Contract.php 755
ERROR - 2019-10-08 08:08:04 --> Severity: error --> Exception: Call to a member function detail_by_contract_number() on null /var/www/html/aset/api/application/controllers/Contract.php 755
ERROR - 2019-10-08 14:53:42 --> Query error: Column 'contract_id' cannot be null - Invalid query: INSERT INTO `invoice` (`contract_id`, `invoice_number`, `due_date`, `create_date`, `billed_amount`, `currency`, `title`, `payment_code`) VALUES (NULL, 'INV-654/LMAN/2019', '2019-11-07', '2019-10-08 14:53:42', '78000000', 'IDR', 'Biaya Sewa Aset Semarang Semeru Tahun 2019 Tahap 3', '98809192000000023')
ERROR - 2019-10-08 14:53:53 --> Query error: Column 'contract_id' cannot be null - Invalid query: INSERT INTO `invoice` (`contract_id`, `invoice_number`, `due_date`, `create_date`, `billed_amount`, `currency`, `title`, `payment_code`) VALUES (NULL, 'INV-654/LMAN/2019', '2019-11-07', '2019-10-08 14:53:53', '78000000', 'IDR', 'Biaya Sewa Aset Semarang Semeru Tahun 2019 Tahap 3', '98809192000000023')
ERROR - 2019-10-08 14:55:21 --> Query error: Column 'contract_id' cannot be null - Invalid query: INSERT INTO `invoice` (`contract_id`, `invoice_number`, `due_date`, `create_date`, `billed_amount`, `currency`, `title`, `payment_code`) VALUES (NULL, 'INV-654/LMAN/2019', '2019-11-07', '2019-10-08 14:55:21', '78000000', 'IDR', 'Biaya Sewa Aset Semarang Semeru Tahun 2019 Tahap 3', '98809192000000023')
ERROR - 2019-10-08 15:44:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tes', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 15:44:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tes', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 15:45:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tes', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 15:45:46 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tesss', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 15:46:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tesss', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 15:46:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`lman_asset_service`.`assets`, CONSTRAINT `assets_ibfk_6` FOREIGN KEY (`asset_category`) REFERENCES `ref_asset_category` (`id`)) - Invalid query: UPDATE `assets` SET `asset_code` = 'Tes', `asset_name` = 'Tes', `asset_description` = ' Tesss ', `minutes_of_handover_number` = 'Tesss', `handover_date` = '2019-10-25', `asset_category` = '7', `asset_origin` = '1', `asset_status` = '2'
WHERE `id` = '26'
ERROR - 2019-10-08 17:02:57 --> 404 Page Not Found: Invoice/invoice_detail
ERROR - 2019-10-08 17:11:04 --> Severity: Notice --> Undefined index: invoice/invoice_detail /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-08 17:11:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:11:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:11:16 --> Severity: Notice --> Undefined index: invoice/invoice_detail /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-08 17:11:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:11:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:12:07 --> Severity: Notice --> Undefined index: invoice/invoice_detail /var/www/html/aset/api/application/libraries/Access_control.php 71
ERROR - 2019-10-08 17:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:12:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/aset/api/application/libraries/Access_control.php 74
ERROR - 2019-10-08 17:12:34 --> Severity: Notice --> Undefined property: stdClass::$asset_id /var/www/html/aset/api/application/controllers/Invoice.php 127
ERROR - 2019-10-08 17:12:34 --> Severity: Notice --> Undefined property: stdClass::$tenant_id /var/www/html/aset/api/application/controllers/Invoice.php 134
ERROR - 2019-10-08 17:16:17 --> Severity: Notice --> Undefined property: Invoice::$Asset_model /var/www/html/aset/api/application/controllers/Invoice.php 130
ERROR - 2019-10-08 17:16:17 --> Severity: error --> Exception: Call to a member function asset_detail() on null /var/www/html/aset/api/application/controllers/Invoice.php 130
ERROR - 2019-10-08 17:16:35 --> Severity: Notice --> Undefined property: stdClass::$tenant_id /var/www/html/aset/api/application/controllers/Invoice.php 137
ERROR - 2019-10-08 17:27:00 --> 404 Page Not Found: Invoice/update_invoice
