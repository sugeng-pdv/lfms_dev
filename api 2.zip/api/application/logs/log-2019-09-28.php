<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-28 02:13:02 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT `id`
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ERROR - 2019-09-28 02:14:08 --> Query error: Unknown column '$due_date_start' in 'where clause' - Invalid query: SELECT `id`
FROM `contract`
WHERE `due_date` >= `$due_date_start`
AND `due_date` <= `$due_date_end`
ERROR - 2019-09-28 02:14:33 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT `id`
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ERROR - 2019-09-28 02:14:59 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:15:25 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:15:28 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:17:01 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:17:04 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:19:46 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:19:47 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:19:47 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:20:38 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/aset/api/application/models/Contract_model.php 55
ERROR - 2019-09-28 02:20:49 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:21:50 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:21:51 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:17 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:18 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:20 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:20 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:21 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:21 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:21 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:22 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:22 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:22 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:22 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:23 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:23 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:23 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:24 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:24 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:24:24 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:25:19 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:25:57 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:49 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:50 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:50 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:51 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:51 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:26:51 --> Query error: Unknown column '2019-10-14' in 'where clause' - Invalid query: SELECT *
FROM `contract`
WHERE `due_date` >= `2019-10-14`
AND `due_date` <= `2019-10-18`
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2019-09-28 02:28:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/aset/api/application/controllers/Contract.php 119
