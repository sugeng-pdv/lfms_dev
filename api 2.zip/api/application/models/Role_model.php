<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Role_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
		$this->db = $this->load->database('default', TRUE);
    }
    
    function get()
    {
        $this->db->where('status','ACTIVE');
		$this->db->order_by('name','asc');
		$query = $this->db->get('acl_role');	
		if ( $result = $query->result() ){ return $result; }
		
	} // end of get() function
	
	function detail( $id='' )
	{
		
		$detail = $this->db->get_where('acl_role', array('id' => $id), 1);			
		if ( $result = $detail->result() ){
			// convert the result from array to object
			foreach ( $result as $data ){}
			return $data;
		}
		
	} // end of detail() function
	
    function insert( $data = array() ) 
    {
		if ($this->db->insert('acl_role', $data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	} // end of insert() function
	
    function update( $id='', $data='' )
    {
		$this->db->where('id', $id);
		if ($this->db->update('acl_role', $data)){
			return true;
		}else{
			return false;
		}
	} // end of update() function
	
    function delete( $id='' )
    {
		$this->db->where('id', $id);
		
		if ($this->db->update('acl_role', array('status'=>'INACTIVE'))){
			return true;
		}else{
			return false;
		}
	} // end of delete() function

	
} // end of class

?>
