<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
(c) Brana Pandega - 198709182008121003
*/

if ( ! function_exists('pwd_verify'))
{
	function pwd_verify( $email_or_nip='', $pwd2check='' ) {
	    
	    $CI = get_instance();
	    
        include_once APPPATH.'/third_party/Requests/Requests.php';
            
        // Next, make sure Requests can load internal classes
        Requests::register_autoloader();
            
        $response = Requests::post( $CI->config->item('sso_endpoint').'login', array(), array('user'=>$email_or_nip, 'password'=>$pwd2check));
        if ( $response->success === true ){
                
            $result = json_decode($response->body);
            //print_r($result);
            if ( $result->status == 'success'){
                return $result->data;
            }else{
                return false;
            }

        }else{
            return false;
        }
		
	} // akhir - fungsi pwd_verify()
}
