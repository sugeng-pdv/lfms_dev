<?php

defined('BASEPATH') OR exit('No direct script access allowed');

if (is_php('5.4')) {
    require_once dirname(__FILE__).'/Format_54.php';
} else {
    require_once dirname(__FILE__).'/Format_53.php';
}
