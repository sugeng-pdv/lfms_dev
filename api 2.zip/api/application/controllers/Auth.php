<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Name		: Auth (Controller)
| Author	: Brana Pandega
|--------------------------------------------------------------------------
*/

class Auth extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        
        // $this->load->model('Asset_model');

		// enable profiler cukup disini
		//$this->output->enable_profiler(true);
		// CORS
		$this->output->set_header('Access-Control-Allow-Origin: *');
		
    }
    
    /*
	public function authority_list(){
	    
	    $this->load->config('access_control');
	    $acl = $this->config->item('access_control');
	    foreach ($acl as $authority => $roles) {
	        foreach ($roles as $role) {
    	        echo "INSERT INTO access_control_list (authority, role) VALUES ('".$authority."','".$role."');";
    	        echo "\r\n";
	        }
	    }
	    
	}*/
    
    // cuma untuk mengecek validitas token yg dikirim melalui header Authorization: Bearer
	public function index(){
	    
	    //sleep(10);
	    
	    $this->lman_security->validate_request_method('GET');
	    
	    if ( VALID_LOGIN === true ){
	        
            $result = array(
                'status' => 'success',
                'message' => null,
                'userid' => USERID,
                'name' => NAME,
                'role_id' => ROLE_ID,
                'role_name' => ROLE_NAME,
                'elapsed_time' => $this->benchmark->elapsed_time(),
            );

	    }else{
            $result = array(
                'status' => 'error',
                'message' => 'Sesi login telah berakhir atau token tidak valid.',
                'elapsed_time' => $this->benchmark->elapsed_time(),
            );
	    }
	    
        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
	    
	}
	
    // update_location - melengkapi atau update data lokasi aset yg meliputi alamat dan koordinat
	public function login(){
	    //$this->lman_security->validate_request_method('POST');
	    
	    $format = $this->input->get('format');
	    if ( $format == 'json' ){
    	    $_POST = json_decode(file_get_contents("php://input"), true);
	    }

        // start form validations
        $this->load->library('form_validation');
        $this->form_validation->set_rules('user', 'User', 'required|max_length[255]');
        $this->form_validation->set_rules('password', 'Password', 'required');

            // if validations returns FALSE statement
            if ($this->form_validation->run() == FALSE) {
                $result = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            }else{
                
                $this->load->helper('pwd_helper');
                $this->load->model('Acl_model');
                
                $employee_detail = pwd_verify($this->input->post('user'), $this->input->post('password'));
                
                if ( $employee_detail != false ){
                    
                    // ambil role, kemudian kirim sebagai array
                    $user_detail = $this->Acl_model->user_detail($employee_detail->userid);
                    
                    if ( !empty($user_detail) ){
                        
                        $this->load->model('Token_model');
                        $this->load->model('Role_model');
                        $jwtuid = uniqid();
                        $this->Token_model->insert(array(
                            'jwt_uid' => $jwtuid,
                            'employee_id' => $employee_detail->userid,
                            'issued' => time()
                            ));
                            
                        $role_detail = $this->Role_model->detail($user_detail->role_id);
                    
                        $token_data = array(
                            "iss" => "asetnegara.id", // issuer
                            "aud" => "asetnegara.id", // audience
                            "iat" => time(), //The time the JWT was issued. Can be used to determine the age of the JWT
                            "nbf" => time(), // not valid before
                            "jwtuid" => $jwtuid, // token unique id
                            "userid" => $employee_detail->userid,
                        );
                        
                        $jwt = $this->access_control->generateJWT($token_data);
                        
                        $result = array(
                                    'status' => 'success',
                                    'message' => null,
                                    'token' => $jwt,
                    				'elapsed_time' => $this->benchmark->elapsed_time(),
                        );
                    
                    }else{
                        $result = array(
                                    'status' => 'error',
                                    'message' => 'Anda tidak memiliki hak akses pada sistem ini.',
                    				'elapsed_time' => $this->benchmark->elapsed_time(),
                        );
                    }
                    
                }else{
                    $result = array(
                                'status' => 'error',
                                'message' => 'User dan/atau password salah.',
                				'elapsed_time' => $this->benchmark->elapsed_time(),
                    );
                }
                
            }

        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
		
	} // end of - login
	
} // akhir - class
