<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends CI_Controller {
    
    function __construct()
    {
        parent::__construct();
        
        $this->load->model('Role_model');

		// enable profiler cukup disini
		//$this->output->enable_profiler(true);
		
    }
    
    // "router" REST API
	public function index()
	{
	    $request_method = $this->input->method(TRUE);
	    switch ( $request_method ) {
	        case 'OPTIONS' :
	            $this->output->set_status_header(200,'Success');
	        break;
	        case 'GET' :
                $this->get();
            break;
	        case 'POST' :
	            $this->add();
	        break;
	        default:
	            $this->output->set_status_header(405,'Method Not Allowed');
	    }
	}
	// akhir - "router" REST API
   
	public function get()
	{
	    $this->lman_security->validate_request_method('GET');
	    //if ( $this->access_control->granted( $this->uri->segment(1).'/'.$this->uri->segment(2)) === true ) {
	        
    		$role = $this->Role_model->get();

            if ( !empty($role) ){
                    $roleArr = array();

                    foreach ( $role as $role ){
        		        array_push($roleArr,$role);
                    }

    			// create result
    			$result = array(
    				'status' => 'success',
    				'message' => null,
    				'elapsed_time' => $this->benchmark->elapsed_time(),
    				'role' => $roleArr
    			);
    
    		}else{
    			// create result
    			$result = array(
    					'status' => 'error',
    					'message' => 'Data role kosong.'
    			);
    		}
		/*
    	} else {
            $result = array(
                'status' => 'error',
                'message' => 'Akses ditolak, Anda belum login, sesi login habis atau tidak memiliki hak akses yang cukup.'
            );
        }
        */

        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
		
	} // end of - get

	public function add()
	{
	    
	    $this->lman_security->validate_request_method('POST');
	    //if ( $this->access_control->granted( $this->uri->segment(1).'/'.$this->uri->segment(2)) === true ) {
	         
            // konversi JSON ke POST 
            $_POST = json_decode(file_get_contents("php://input"), true);
	         
            // start form validations
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Nama Role', 'required');
            $this->form_validation->set_error_delimiters("", "\r\n");

            // if validations returns FALSE statement
            if ($this->form_validation->run() == FALSE) {
                $result = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            } else {

                $role_detail = array(
                    'name' => $this->lman_security->clean_post('name'),
                    'description' => $this->lman_security->clean_post('description'),
                );
                
                $role_id = $this->Role_model->insert($role_detail);
                if ($role_id != false) {
                    $result = array(
                        'status' => 'success',
                        'message' => null,
        				'elapsed_time' => $this->benchmark->elapsed_time(),
                        'role_id' => $role_id,
                    );
                } else {
                    $result = array(
                        'status' => 'error',
                        'message' => 'Gagal menyimpan data ke database, silakan coba lagi!'
                    );
                }
                
            }

    	/*} else {
            $result = array(
                'status' => 'error',
                'message' => 'Akses ditolak, Anda belum login, sesi login habis atau tidak memiliki hak akses yang cukup.'
            );
        }*/

        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
		
	} // end of - add
	
	public function update( $role_id=null )
	{
	    $this->lman_security->validate_request_method('POST');
	    //if ( $this->access_control->granted( $this->uri->segment(1).'/'.$this->uri->segment(2)) === true ) {
	         
            // konversi JSON ke POST 
            $_POST = json_decode(file_get_contents("php://input"), true);
	         
            // start form validations
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Nama Role', 'required');
            $this->form_validation->set_error_delimiters("", "\r\n");

            // if validations returns FALSE statement
            if ($this->form_validation->run() == FALSE) {
                $result = array(
                    'status' => 'error',
                    'message' => validation_errors()
                );
            } else {

                $role_detail = array(
                    'name' => $this->lman_security->clean_post('name'),
                    'description' => $this->lman_security->clean_post('description'),
                );
                
                $role_id = $this->Role_model->update($role_id, $role_detail);
                if ($role_id != false) {
                    $result = array(
                        'status' => 'success',
                        'message' => null,
        				'elapsed_time' => $this->benchmark->elapsed_time(),
                        'role_id' => $role_id,
                    );
                } else {
                    $result = array(
                        'status' => 'error',
                        'message' => 'Gagal menyimpan data ke database, silakan coba lagi!'
                    );
                }
                
            }

    	/*} else {
            $result = array(
                'status' => 'error',
                'message' => 'Akses ditolak, Anda belum login, sesi login habis atau tidak memiliki hak akses yang cukup.'
            );
        }*/

        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
	} // end of - update
	
	public function delete( $role_id=null )
	{
	    $this->lman_security->validate_request_method('GET');
	    //if ( $this->access_control->granted( $this->uri->segment(1).'/'.$this->uri->segment(2)) === true ) {
	         
            // if validations returns FALSE statement
            if ( $role_id == '1') {
                $result = array(
                    'status' => 'error',
                    'message' => 'Role Administrator tidak dapat dihapus.'
                );
            } else {

                $delete_role = $this->Role_model->delete($role_id);
                if ($delete_role != false) {
                    $result = array(
                        'status' => 'success',
                        'message' => null,
        				'elapsed_time' => $this->benchmark->elapsed_time(),
                    );
                } else {
                    $result = array(
                        'status' => 'error',
                        'message' => 'Gagal menyimpan data ke database, silakan coba lagi!'
                    );
                }
                
            }

    	/*} else {
            $result = array(
                'status' => 'error',
                'message' => 'Akses ditolak, Anda belum login, sesi login habis atau tidak memiliki hak akses yang cukup.'
            );
        }*/

        // json result
        $this->output->set_content_type('application/json')->set_output(json_encode($result));
	} // end of - delete()

}
